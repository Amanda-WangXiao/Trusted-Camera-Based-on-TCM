#ifndef WHITELIST_CHECK_H
#define WHITELIST_CHECK_H
 
 
int whitelist_check_init (void * sub_proc, void * para);
int whitelist_check_start (void * sub_proc, void * para);
#endif
