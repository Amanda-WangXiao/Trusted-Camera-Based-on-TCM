#ifndef WHITELIST_SEARCH_H
#define WHITELIST_SEARCH_H
 
 
int whitelist_search_init (void * sub_proc, void * para);
int whitelist_search_start (void * sub_proc, void * para);
#endif
