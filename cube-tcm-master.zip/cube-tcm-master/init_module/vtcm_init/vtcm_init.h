#ifndef VTCM_INIT_H
#define VTCM_INIT_H
int vtpm_init(void * sub_proc,void * para);
#endif
