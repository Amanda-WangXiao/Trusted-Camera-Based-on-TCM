#ifndef VTCM_SWITCH_H
#define VTCM_SWITCH_H

int vtcm_switch_init(void * sub_proc,void * para);
int vtcm_switch_start(void * sub_proc,void * para);

#endif
