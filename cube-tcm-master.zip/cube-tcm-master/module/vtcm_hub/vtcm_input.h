#ifndef VTCM_INPUT_H
#define VTCM_INPUT_H

int vtcm_input_init(void * sub_proc,void * para);
int vtcm_input_start(void * sub_proc,void * para);

#endif
