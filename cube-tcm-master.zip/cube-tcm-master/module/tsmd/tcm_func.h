#ifndef TSMD_TCM_FUNC_H
#define TSMD_TCM_FUNC_H

int proc_tcm_GetRandom(void * tcm_in, void * tcm_out, CHANNEL * vtcm_caller);
int proc_tcm_Extend(void * tcm_in, void * tcm_out, CHANNEL * vtcm_caller);
#endif
