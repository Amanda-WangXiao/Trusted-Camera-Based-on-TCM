#ifndef VTCM_AUTO_H
#define VTCM_AUTO_H

int vtcm_auto_init(void * sub_proc,void * para);
int vtcm_auto_start(void * sub_proc,void * para);

#endif
