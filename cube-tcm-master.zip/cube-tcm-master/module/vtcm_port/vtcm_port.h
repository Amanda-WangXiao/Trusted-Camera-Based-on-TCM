#ifndef VTCM_PORT_H
#define VTCM_PORT_H
int vtcm_port_init(void * sub_proc,void * para);
int vtcm_port_start(void * sub_proc,void * para);
#endif
