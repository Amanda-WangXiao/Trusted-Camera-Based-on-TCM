#ifndef VTCM_STORE_H
#define VTCM_STORE_H

int vtcm_store_init(void * sub_proc,void * para);
int vtcm_store_start(void * sub_proc,void * para);

#endif
