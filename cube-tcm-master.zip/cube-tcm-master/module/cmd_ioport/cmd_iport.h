#ifndef CMD_IOPORT_H
#define CMD_IOPORT_H

int cmd_ioport_init(void * sub_proc,void * para);
int cmd_ioport_start(void * sub_proc,void * para);

#endif
