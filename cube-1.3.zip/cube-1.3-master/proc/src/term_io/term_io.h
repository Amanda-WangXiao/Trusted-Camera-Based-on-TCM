#ifndef TERM_IO_H
#define TERM_IO_H

int term_io_init(void * sub_proc,void * para);
int term_io_start(void * sub_proc,void * para);

#endif
