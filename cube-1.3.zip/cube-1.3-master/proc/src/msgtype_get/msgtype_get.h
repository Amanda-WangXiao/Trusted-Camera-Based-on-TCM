#ifndef MSGTYPE_GET_H
#define MSGTYPE_GET_H


// plugin's init func and kickstart func
int msgtype_get_init(void * sub_proc,void * para);
int msgtype_get_start(void * sub_proc,void * para);

#endif
