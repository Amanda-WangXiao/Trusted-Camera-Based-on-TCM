#ifndef ECHO_PLUGIN_FUNC_H
#define ECHO_PLUGIN_FUNC_H


// plugin's init func and kickstart func
int bubble_sort_init(void * sub_proc,void * para);
int bubble_sort_start(void * sub_proc,void * para);

#endif
